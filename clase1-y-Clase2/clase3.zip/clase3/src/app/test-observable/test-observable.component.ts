import { Component, OnInit } from '@angular/core';

import { Subscription, timer } from 'rxjs';
import { filter, map } from 'rxjs/operators';

@Component({
  selector: 'app-test-observable',
  templateUrl: './test-observable.component.html',
  styleUrls: ['./test-observable.component.css']
})
export class TestObservableComponent implements OnInit {


  subscription: Subscription | null = null;

  constructor() { }

  ngOnInit(): void {
    this.subscription = timer(0, 500)
      .pipe(
        filter((data: number) => data % 2 === 0),
        map((data: number) => data - 1),
      )
      .subscribe(data => console.log(data));
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }

  }

}
