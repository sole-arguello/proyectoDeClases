import { Injectable } from '@angular/core';
import { User } from './user-list/user-list.component';

import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  // atributos
  // metodos

  constructor(private http: HttpClient) {
    // Typescript
    // Generics
    const countries$ = this.http.get('https://jsonplaceholder.typicode.com/todos/1');

    countries$.subscribe({
      next: (data) => console.log(data),
      error: (err) => console.warn(err)
    });

  }

  users: User[] = [
    // { id: 1, name: 'Gaston', age: 35 },
    { id: 2, name: 'Fernando', age: 17 },
    { id: 3, name: 'Soledad', age: 27 },
    { id: 4, name: 'Florencia', age: 27 },
  ];

  addUser(newUser: User) {
    if (!this.users.find(user => user.name === newUser.name)) {
      this.users.push(newUser);

    }
  }
}
