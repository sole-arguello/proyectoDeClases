import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-listado',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoComponent {

  @Input()
  paises: string[] = [];

  @Input()
  userId: number | null = null;

  @Output()
  borrarPais = new EventEmitter();

  // Ciclos de vida
  // Constructor
  constructor() {
    console.log("Constructor del listado", this.paises.length);
  }

  // onInit
  ngOnInit(): void {
    console.log("ngOnInit del listado", this.paises.length);
    // Consumir un server pasandole el id del usuario
  }

  // AfterViewInit
  ngAfterViewInit(): void {
    console.log("ngAfterViewInit del listado", this.paises.length);
  }

  // ondestroy
  ngOnDestroy(): void {
    console.log("ngOnDestroy del listado", this.paises.length);
  }


  removePais(paisABorrar: string) {
    this.borrarPais.emit(paisABorrar);
  }
}
