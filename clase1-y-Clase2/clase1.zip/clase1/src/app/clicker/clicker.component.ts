import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-clicker',
  templateUrl: './clicker.component.html',
  styleUrls: ['./clicker.component.css']
})
export class ClickerComponent {
  // Property Binding
  @Input()
  number: number = 0;

  @Output()
  clickEmitter = new EventEmitter();

  numberColor: string = 'aqua';


  // Event Binding
  incrementar() {
    this.number = this.number + 1;
    this.clickEmitter.emit();
  }

  decrementar() {
    this.number = this.number - 1;
    this.clickEmitter.emit();
  }

  reset() {
    this.number = 0;
  }


  // Directivas
  //  Estructurales
  //    *ngIf / *ngFor / *ngSwitch
  //  Modificadoras de estilo
  //    ngClass / ngStyle

}
